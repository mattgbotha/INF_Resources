export interface RegisterUser {
    emailaddress: string;
    password: string;
}
