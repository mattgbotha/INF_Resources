export interface ProductTypes {
    productTypeId: number;
    name: string;
}
