namespace ApplicationSecurity_Backend.Models
{
    public interface IRepository
    {
        Task<Course[]> GetAllCoursesAsync();
    }
}
